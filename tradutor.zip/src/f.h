#include <stdio.h>

#include "ArvoreAVL.h"

ArvAVL *lerDict(FILE *fdict);
